export * from './angularfire2';
//# sourceMappingURL=index.js.map