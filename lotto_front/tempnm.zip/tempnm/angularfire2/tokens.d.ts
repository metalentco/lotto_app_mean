import { InjectionToken } from '@angular/core';
export declare const FirebaseConfig: InjectionToken<any>;
export declare const FirebaseApp: InjectionToken<any>;
export declare const FirebaseAuthConfig: InjectionToken<any>;
export declare const FirebaseUserConfig: InjectionToken<any>;
export declare const FirebaseAppName: InjectionToken<any>;
export declare const WindowLocation: InjectionToken<any>;
export declare const FirebaseRef: InjectionToken<any>;
export declare const FirebaseUrl: InjectionToken<any>;
